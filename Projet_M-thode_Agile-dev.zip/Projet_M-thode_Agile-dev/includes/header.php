<!-- En-tête de la page avec le logo et le texte -->
<div class="container">
    <div class="texte_header">
        <h1>Gestion de Stock</h1>
    </div>
</div>

<!-- Container pour les événements et les boutons d'action -->
<div class="event-container">
    <div class="boutons">
        <a href="formulaireConnexion.php"><button class="login-button">Connexion</button></a>
    </div>
</div>
