<!-- En-tête de la page avec le logo et le texte -->
<div class="container">
    <div class="texte_footer">
        <p>@2024-2025</p>
    </div>
</div>
